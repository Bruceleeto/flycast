/* Threaded VMU Profiler 
   Original by Falco Girgis
   C port for KallistiOS (No Sound Version)
*/

#ifndef VMU_PROFILER_H
#define VMU_PROFILER_H

#include <kos.h>
#include <malloc.h>
#include <stdbool.h>

// Constants
#define VMU_UPDATE_RATE_MS 100
#define FPS_SAMPLES 10
#define MB_SIZE (1024.0f * 1024.0f)

// Structure to hold profiler state
typedef struct {
    kthread_t* thread;
    vmufb_t framebuffer;
    mutex_t mutex;
    volatile bool done;
    float fps[FPS_SAMPLES];
    size_t fps_frame;
    size_t vertex_count;
} vmu_profiler_t;

// Global instance
static vmu_profiler_t* g_profiler = NULL;

// Thread function
static void* vmu_profiler_thread(void* param) {
    vmu_profiler_t* profiler = (vmu_profiler_t*)param;
    
    while (!profiler->done) {
        maple_device_t* dev = maple_enum_type(0, MAPLE_FUNC_MEMCARD);
        
        if (dev) {
            pvr_stats_t pvr_stats;
            struct mallinfo m_info;
            size_t pvr_avail;
            float fps, sh4_mem, pvr_mem;
            
            pvr_get_stats(&pvr_stats);
            m_info = mallinfo();
            pvr_avail = pvr_mem_available();
            
            mutex_lock(&profiler->mutex);
            
            // Calculate average FPS
            fps = 0;
            for (int i = 0; i < FPS_SAMPLES; i++) {
                fps += profiler->fps[i];
            }
            fps /= FPS_SAMPLES;
            
            // Calculate SH4 and PVR memory usage
            sh4_mem = (float)m_info.uordblks / 
                     (float)(m_info.uordblks + m_info.fordblks) * 100.0f;
            pvr_mem = ((8 * MB_SIZE) - pvr_avail) / (8 * MB_SIZE) * 100.0f;
            
            // VMU display format
            vmu_printf("FPS:%5.1f\n"
                      "SH4:%5.1f%%\n"
                      "PVR:%5.1f%%\n"
                      "VTX:%5u",
                      fps, sh4_mem, pvr_mem,
                      profiler->vertex_count);
            
            mutex_unlock(&profiler->mutex);
        }
        
        thd_sleep(VMU_UPDATE_RATE_MS);
    }
    
    return NULL;
}

// Initialize the profiler
static vmu_profiler_t* vmu_profiler_init(void) {
    if (g_profiler) return g_profiler;
    
    vmu_profiler_t* profiler = (vmu_profiler_t*)calloc(1, sizeof(vmu_profiler_t));
    if (!profiler) return NULL;
    
    mutex_init(&profiler->mutex, MUTEX_TYPE_NORMAL);
    profiler->done = false;
    profiler->fps_frame = 0;
    profiler->vertex_count = 0;
    
    // Initialize FPS array
    for (int i = 0; i < FPS_SAMPLES; i++) {
        profiler->fps[i] = 0.0f;
    }
    
    // Create and start the thread
    profiler->thread = thd_create(0, vmu_profiler_thread, profiler);
    if (!profiler->thread) {
        free(profiler);
        return NULL;
    }
    
    g_profiler = profiler;
    return profiler;
}

// Shutdown the profiler
static void vmu_profiler_shutdown(vmu_profiler_t* profiler) {
    if (!profiler) return;
    
    profiler->done = true;
    thd_join(profiler->thread, NULL);
    mutex_destroy(&profiler->mutex);
    free(profiler);
    
    if (g_profiler == profiler) {
        g_profiler = NULL;
    }
}

// Update vertex count and FPS (call this every frame)
static void vmu_profiler_update(vmu_profiler_t* profiler, size_t vertex_count) {
    if (!profiler) return;
    
    pvr_stats_t pvr_stats;
    
    mutex_lock(&profiler->mutex);
    
    profiler->vertex_count = vertex_count;
    pvr_get_stats(&pvr_stats);
    profiler->fps[profiler->fps_frame++] = pvr_stats.frame_rate;
    
    if (profiler->fps_frame >= FPS_SAMPLES) {
        profiler->fps_frame = 0;
    }
    
    mutex_unlock(&profiler->mutex);
}

#endif // VMU_PROFILER_H