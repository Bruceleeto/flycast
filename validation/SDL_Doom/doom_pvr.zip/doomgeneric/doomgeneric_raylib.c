#include "doomkeys.h"
#include "m_argv.h"
#include "doomgeneric.h"

#include <dc/pvr.h>
#include <dc/video.h>
#include <dc/sq.h>
#include <kos.h>
#include <arch/timer.h>
#include <assert.h>

#define DOOM_WIDTH  320
#define DOOM_HEIGHT 200

/* PVR texture size in pixels - power of 2 aligned */
#define TEX_WIDTH  1024
#define TEX_HEIGHT 512

static pvr_ptr_t pvram;
static uint32_t *pvram_sq;
static int started = 0;

static inline uint16_t rgba8888_to_rgb565(uint32_t rgba) {
    uint8_t b = (rgba >> 0) & 0xff;
    uint8_t g = (rgba >> 8) & 0xff;
    uint8_t r = (rgba >> 16) & 0xff;

    return ((r & 0xf8) << 8) |    // 5 bits red
           ((g & 0xfc) << 3) |    // 6 bits green
           ((b & 0xf8) >> 3);     // 5 bits blue
}

static inline void copy_frame_to_texture() {
    const uint32_t *src = (const uint32_t *)DG_ScreenBuffer;
    uint32_t *dest = pvram_sq;
    int x, y;

    for (y = 0; y < DOOM_HEIGHT; y++) {
        uint32_t *line = SQ_MASK_DEST(dest);
        
        sq_lock(dest);
        
        for (x = 0; x < DOOM_WIDTH; x += 16) {
            uint32_t output[8];
            
            for(int i = 0; i < 8; i++) {
                uint16_t p1 = rgba8888_to_rgb565(src[i * 2]);
                uint16_t p2 = rgba8888_to_rgb565(src[i * 2 + 1]);
                output[i] = (p2 << 16) | p1;
            }
            
            memcpy(line, output, sizeof(output));
            sq_flush(line);
            
            line += 8;
            src += 16;
        }
        
        dest += TEX_WIDTH / 2;
        sq_unlock();
    }
}

void DG_Init() {
    /* Initialize the PVR */
    pvr_init_defaults();
    
    /* Set video mode to 640x480 interlaced */
    vid_set_mode(DM_640x480_NTSC_IL, PM_RGB565);
    
    /* Allocate texture memory */
    pvram = pvr_mem_malloc(TEX_WIDTH * TEX_HEIGHT * 2);
    assert(pvram != NULL);
    assert(!((unsigned int)pvram & 0x1f));
    
    /* Setup SQ access to texture memory */
    pvram_sq = (uint32_t *)(((uintptr_t)pvram & 0xffffff) | PVR_TA_TEX_MEM);
    
    started = 1;
}

void DG_DrawFrame() {
    pvr_poly_cxt_t cxt;
    pvr_poly_hdr_t hdr;
    pvr_vertex_t vert;
    
    if (!started || !DG_ScreenBuffer) return;

    /* Copy Doom's frame buffer to PVR texture */
    copy_frame_to_texture();

    /* Wait for PVR */
    pvr_wait_ready();
    
    /* Begin scene */
    pvr_scene_begin();
    pvr_list_begin(PVR_LIST_OP_POLY);

    /* Setup polygon context */
    pvr_poly_cxt_txr(&cxt, PVR_LIST_OP_POLY,
                     PVR_TXRFMT_RGB565 | PVR_TXRFMT_NONTWIDDLED,
                     TEX_WIDTH, TEX_HEIGHT, pvram, PVR_FILTER_BILINEAR);
    
    cxt.gen.alpha = PVR_ALPHA_DISABLE;
    cxt.gen.culling = PVR_CULLING_NONE;
    cxt.depth.comparison = PVR_DEPTHCMP_ALWAYS;
    cxt.depth.write = PVR_DEPTHWRITE_DISABLE;
    
    pvr_poly_compile(&hdr, &cxt);
    pvr_prim(&hdr, sizeof(hdr));

    /* Draw textured quad to fill 640x480 */
    vert.argb = PVR_PACK_COLOR(1.0f, 1.0f, 1.0f, 1.0f);
    vert.oargb = 0;
    vert.flags = PVR_CMD_VERTEX;
    
    /* Top-left */
    vert.x = 0.0f;
    vert.y = 0.0f;
    vert.z = 1.0f;
    vert.u = 0.0f;
    vert.v = 0.0f;
    pvr_prim(&vert, sizeof(vert));
    
    /* Top-right */
    vert.x = 640.0f;
    vert.u = (float)DOOM_WIDTH / (float)TEX_WIDTH;
    pvr_prim(&vert, sizeof(vert));
    
    /* Bottom-left */
    vert.x = 0.0f;
    vert.y = 480.0f;
    vert.u = 0.0f;
    vert.v = (float)DOOM_HEIGHT / (float)TEX_HEIGHT;
    pvr_prim(&vert, sizeof(vert));
    
    /* Bottom-right */
    vert.x = 640.0f;
    vert.u = (float)DOOM_WIDTH / (float)TEX_WIDTH;
    vert.flags = PVR_CMD_VERTEX_EOL;
    pvr_prim(&vert, sizeof(vert));

    /* End scene */
    pvr_list_finish();
    pvr_scene_finish();
}

void DG_SleepMs(uint32_t ms) {
    thd_sleep(ms);
}

uint32_t DG_GetTicksMs() {
    uint32_t secs, msecs;
    timer_ms_gettime(&secs, &msecs);
    return (secs * 1000) + msecs;
}

int DG_GetKey(int* pressed, unsigned char* doomKey) {
    maple_device_t *cont;
    cont_state_t *state;
    
    cont = maple_enum_type(0, MAPLE_FUNC_CONTROLLER);
    if (!cont) return 0;
        
    state = (cont_state_t *)maple_dev_status(cont);
    if (!state) return 0;

    /* Controller mapping:
       D-Pad: Movement
       A: Fire
       B: Use/Open
       X: Run (can be combined with direction)
       Start: ESC/Menu */

    if (state->buttons & CONT_DPAD_UP) {
        *pressed = 1;
        *doomKey = KEY_UPARROW;
        return 1;
    }
    if (state->buttons & CONT_DPAD_DOWN) {
        *pressed = 1;
        *doomKey = KEY_DOWNARROW;
        return 1;
    }
    if (state->buttons & CONT_DPAD_LEFT) {
        *pressed = 1;
        *doomKey = KEY_LEFTARROW;
        return 1;
    }
    if (state->buttons & CONT_DPAD_RIGHT) {
        *pressed = 1;
        *doomKey = KEY_RIGHTARROW;
        return 1;
    }
    if (state->buttons & CONT_A) {
        *pressed = 1;
        *doomKey = KEY_FIRE;
        return 1;
    }
    if (state->buttons & CONT_B) {
        *pressed = 1;
        *doomKey = KEY_USE;
        return 1;
    }
    if (state->buttons & CONT_X) {
        *pressed = 1;
        *doomKey = KEY_RSHIFT;  // Run key
        return 1;
    }
    if (state->buttons & CONT_Y) {
    *pressed = 1;
    *doomKey = KEY_ENTER;  // Y button as Enter key
    return 1;
    }

    if (state->buttons & CONT_START) {
        *pressed = 1;
        *doomKey = KEY_ESCAPE;
        return 1;
    }

    // If no button is pressed
    *pressed = 0;
    *doomKey = 0;
    return 0;
}

void DG_SetWindowTitle(const char* title) {
    /* No-op on Dreamcast */
}

int main(int argc, char **argv) {
    DG_Init();
    doomgeneric_Create(argc, argv);

    while (1) {
        doomgeneric_Tick();
    }

    return 0;
}