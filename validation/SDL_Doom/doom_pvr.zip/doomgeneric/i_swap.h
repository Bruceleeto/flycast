//
// Copyright(C) 1993-1996 Id Software, Inc.
// Copyright(C) 2005-2014 Simon Howard
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//  Endianess handling, swapping 16bit and 32bit.
//

#ifndef __I_SWAP__
#define __I_SWAP__

#ifdef FEATURE_SOUND

#ifdef __DJGPP__

#define SHORT(x)  ((signed short) (x))
#define LONG(x)   ((signed int) (x))

#define SYS_LITTLE_ENDIAN

#else  // __DJGPP__

#include <stdint.h>

// Endianess handling.
// WAD files are stored little endian.

// Define the byte swapping functions for platforms that support it

#if defined(__GNUC__) || defined(__clang__)
    // Using GCC/Clang built-in functions for byte swapping
    #define SHORT(x)  ((signed short) __builtin_bswap16((uint16_t)(x)))
    #define LONG(x)   ((signed int) __builtin_bswap32((uint32_t)(x)))
#elif defined(_MSC_VER)
    // Using Microsoft Visual Studio built-in functions for byte swapping
    #include <stdlib.h>
    #define SHORT(x)  ((signed short) _byteswap_ushort((uint16_t)(x)))
    #define LONG(x)   ((signed int) _byteswap_ulong((uint32_t)(x)))
#else
    // Fallback manual implementation of byte swapping
    #define SHORT(x)  ((signed short) ((((x) & 0xFF00) >> 8) | (((x) & 0x00FF) << 8)))
    #define LONG(x)   ((signed int) ((((x) & 0xFF000000) >> 24) | (((x) & 0x00FF0000) >> 8) | (((x) & 0x0000FF00) << 8) | (((x) & 0x000000FF) << 24)))
#endif

// Define system endianness based on common macros
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
    #define SYS_LITTLE_ENDIAN
#elif defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
    #define SYS_BIG_ENDIAN
#elif defined(_WIN32) || defined(__LITTLE_ENDIAN__)
    #define SYS_LITTLE_ENDIAN
#else
    #define SYS_BIG_ENDIAN
#endif

// Custom swap function for short values (if needed elsewhere)
#define doom_swap_s(x) \
    ((short int)((((unsigned short int)(x) & 0x00ff) << 8) | \
                 (((unsigned short int)(x) & 0xff00) >> 8)))

#if defined(SYS_BIG_ENDIAN)
    #define doom_wtohs(x) doom_swap_s(x)
#else
    #define doom_wtohs(x) (short int)(x)
#endif

#endif  // __DJGPP__

#else  // FEATURE_SOUND

#define SHORT(x)  ((signed short) (x))
#define LONG(x)   ((signed int) (x))

#define SYS_LITTLE_ENDIAN

#endif /* FEATURE_SOUND */

#endif  // __I_SWAP__
