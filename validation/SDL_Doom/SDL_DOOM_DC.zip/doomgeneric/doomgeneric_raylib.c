#include "doomkeys.h"
#include "m_argv.h"
#include "doomgeneric.h"

#include <SDL/SDL.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>

SDL_Surface* screen = NULL;

#define DOOM_WIDTH  320
#define DOOM_HEIGHT 200

void DG_Init() {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        exit(1);
    }

    // Set up screen at DOOM's native resolution
    screen = SDL_SetVideoMode(DOOM_WIDTH, DOOM_HEIGHT, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (!screen) {
        screen = SDL_SetVideoMode(DOOM_WIDTH, DOOM_HEIGHT, 32, SDL_HWSURFACE);
    }
    if (!screen) {
        fprintf(stderr, "SDL_SetVideoMode failed: %s\n", SDL_GetError());
        exit(1);
    }

    // Clear screen
    SDL_FillRect(screen, NULL, 0);
    SDL_Flip(screen);
}

void DG_DrawFrame() {
    if (!screen || !DG_ScreenBuffer) return;

    // Frame timing
    static uint32_t next_frame = 0;
    uint32_t now = SDL_GetTicks();
    if (now < next_frame) {
        SDL_Delay(next_frame - now);
    }
    next_frame = now + (1000/35);

    if (SDL_MUSTLOCK(screen)) {
        if (SDL_LockSurface(screen) < 0) return;
    }

    // Direct pixel copy, one line at a time to handle pitch correctly
    uint32_t* src = (uint32_t*)DG_ScreenBuffer;
    uint32_t* dest = (uint32_t*)screen->pixels;
    int pitch = screen->pitch / sizeof(uint32_t);
    
    for (int y = 0; y < DOOM_HEIGHT; y++) {
        memcpy(&dest[y * pitch], 
               &src[y * DOOM_WIDTH], 
               DOOM_WIDTH * sizeof(uint32_t));
    }

    if (SDL_MUSTLOCK(screen)) {
        SDL_UnlockSurface(screen);
    }

    SDL_Flip(screen);
}

void DG_SleepMs(uint32_t ms) {
    SDL_Delay(ms);
}

uint32_t DG_GetTicksMs() {
    return SDL_GetTicks();
}

int DG_GetKey(int* pressed, unsigned char* doomKey) {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                exit(0);
                break;
            case SDL_KEYDOWN:
            case SDL_KEYUP:
                *pressed = (event.type == SDL_KEYDOWN);
                *doomKey = event.key.keysym.sym;
                return 1;
        }
    }
    return 0;
}

void DG_SetWindowTitle(const char* title) {
    SDL_WM_SetCaption(title, NULL);
}

int main(int argc, char **argv) {
    DG_Init();
    doomgeneric_Create(argc, argv);

    while (1) {
        doomgeneric_Tick();
    }

    SDL_Quit();
    return 0;
}